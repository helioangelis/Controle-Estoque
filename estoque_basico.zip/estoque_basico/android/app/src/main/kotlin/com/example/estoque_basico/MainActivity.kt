package com.example.estoque_basico

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
