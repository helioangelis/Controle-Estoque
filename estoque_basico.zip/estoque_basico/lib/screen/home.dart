import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../database.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final Database _db = Database.instance;
  List<Map<String, dynamic>> _produtos = [];
  Map<String, dynamic> _estatisticas = {};
  final TextEditingController _nomeController = TextEditingController();
  final TextEditingController _quantidadeController = TextEditingController();
  final TextEditingController _precoController = TextEditingController();
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _carregarDados();
  }

  Future<void> _carregarDados() async {
    setState(() => _isLoading = true);
    final produtos = await _db.getProdutos();
    final stats = await _db.getEstatisticas();
    setState(() {
      _produtos = produtos;
      _estatisticas = stats;
      _isLoading = false;
    });
  }

  Future<void> _adicionarProduto() async {
    final nome = _nomeController.text.trim();
    final quantidade = int.tryParse(_quantidadeController.text);
    final preco = double.tryParse(_precoController.text.replaceAll(',', '.'));

    if (nome.isEmpty || quantidade == null || preco == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Preencha todos os campos')),
      );
      return;
    }

    await _db.addProduto(nome, quantidade, preco);
    _nomeController.clear();
    _quantidadeController.clear();
    _precoController.clear();
    _carregarDados();
    
    if (mounted) {
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Produto adicionado')),
      );
    }
  }

  Future<void> _movimentarEstoque(int id, int quantidadeAtual, bool entrada) async {
    final controller = TextEditingController();
    
    await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(entrada ? 'Adicionar ao Estoque' : 'Remover do Estoque'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('Estoque atual: $quantidadeAtual'),
            const SizedBox(height: 16),
            TextField(
              controller: controller,
              decoration: const InputDecoration(
                labelText: 'Quantidade',
                border: OutlineInputBorder(),
              ),
              keyboardType: TextInputType.number,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () {
              final qtd = int.tryParse(controller.text);
              if (qtd != null && qtd > 0) {
                final novaQuantidade = entrada 
                    ? quantidadeAtual + qtd 
                    : quantidadeAtual - qtd;
                
                if (novaQuantidade >= 0) {
                  Navigator.pop(context);
                  _db.updateQuantidade(id, novaQuantidade);
                  _carregarDados();
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text(entrada ? 'Entrada registrada' : 'Saída registrada')),
                  );
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Quantidade insuficiente')),
                  );
                }
              }
            },
            child: const Text('Confirmar'),
          ),
        ],
      ),
    );
  }

  Future<void> _deletarProduto(int id) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Confirmar'),
        content: const Text('Deseja excluir este produto?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancelar'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Excluir', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );

    if (confirm == true) {
      await _db.deleteProduto(id);
      _carregarDados();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Produto excluído')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final currencyFormat = NumberFormat.currency(locale: 'pt_BR', symbol: 'R\$');

    return Scaffold(
      appBar: AppBar(
        title: const Text('Controle de Estoque'),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                // Estatísticas
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    children: [
                      Expanded(
                        child: _buildStatCard(
                          'Total',
                          '${_estatisticas['totalProdutos'] ?? 0}',
                          Icons.inventory_2,
                          Colors.blue,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: _buildStatCard(
                          'Itens',
                          '${_estatisticas['totalQuantidade'] ?? 0}',
                          Icons.shopping_bag,
                          Colors.green,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: _buildStatCard(
                          'Valor',
                          currencyFormat.format(_estatisticas['valorTotal'] ?? 0),
                          Icons.attach_money,
                          Colors.purple,
                        ),
                      ),
                    ],
                  ),
                ),

                // Lista de produtos
                Expanded(
                  child: _produtos.isEmpty
                      ? const Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.inventory, size: 64, color: Colors.grey),
                              SizedBox(height: 16),
                              Text('Nenhum produto cadastrado'),
                            ],
                          ),
                        )
                      : ListView.builder(
                          padding: const EdgeInsets.symmetric(horizontal: 16),
                          itemCount: _produtos.length,
                          itemBuilder: (context, index) {
                            final produto = _produtos[index];
                            final quantidade = produto['quantidade'] as int;
                            final preco = produto['preco'] as double;
                            
                            return Card(
                              margin: const EdgeInsets.only(bottom: 8),
                              child: ListTile(
                                leading: Icon(
                                  quantidade == 0 ? Icons.error : Icons.inventory,
                                  color: quantidade == 0 ? Colors.red : Colors.blue,
                                ),
                                title: Text(produto['nome'] as String),
                                subtitle: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text('Quantidade: $quantidade'),
                                    Text('Preço: ${currencyFormat.format(preco)}'),
                                  ],
                                ),
                                trailing: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    IconButton(
                                      icon: const Icon(Icons.add, color: Colors.green),
                                      onPressed: () => _movimentarEstoque(
                                        produto['id'] as int,
                                        quantidade,
                                        true,
                                      ),
                                    ),
                                    IconButton(
                                      icon: const Icon(Icons.remove, color: Colors.orange),
                                      onPressed: () => _movimentarEstoque(
                                        produto['id'] as int,
                                        quantidade,
                                        false,
                                      ),
                                    ),
                                    IconButton(
                                      icon: const Icon(Icons.delete, color: Colors.red),
                                      onPressed: () => _deletarProduto(produto['id'] as int),
                                    ),
                                  ],
                                ),
                                isThreeLine: true,
                              ),
                            );
                          },
                        ),
                ),
              ],
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showDialogAdicionar(),
        child: const Icon(Icons.add),
      ),
    );
  }

  Widget _buildStatCard(String label, String value, IconData icon, Color color) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            Icon(icon, color: color, size: 24),
            const SizedBox(height: 4),
            Text(
              value,
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              label,
              style: TextStyle(
                fontSize: 12,
                color: Colors.grey[600],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showDialogAdicionar() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Adicionar Produto'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: _nomeController,
              decoration: const InputDecoration(
                labelText: 'Nome do produto',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _quantidadeController,
              decoration: const InputDecoration(
                labelText: 'Quantidade',
                border: OutlineInputBorder(),
              ),
              keyboardType: TextInputType.number,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _precoController,
              decoration: const InputDecoration(
                labelText: 'Preço',
                border: OutlineInputBorder(),
              ),
              keyboardType: TextInputType.numberWithOptions(decimal: true),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: _adicionarProduto,
            child: const Text('Adicionar'),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _nomeController.dispose();
    _quantidadeController.dispose();
    _precoController.dispose();
    super.dispose();
  }
}
