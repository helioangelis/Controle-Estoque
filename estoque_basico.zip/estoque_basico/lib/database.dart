import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class Database {
  static final Database instance = Database._init();
  static Database? _database;

  Database._init();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('estoque.db');
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, filePath);

    return await openDatabase(
      path,
      version: 1,
      onCreate: _createDB,
    );
  }

  Future<void> _createDB(Database db, int version) async {
    await db.execute('''
      CREATE TABLE produtos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT NOT NULL,
        quantidade INTEGER NOT NULL,
        preco REAL NOT NULL,
        data_cadastro TEXT NOT NULL
      )
    ''');

    // Produtos de exemplo
    await db.insert('produtos', {
      'nome': 'Produto A',
      'quantidade': 10,
      'preco': 25.50,
      'data_cadastro': DateTime.now().toIso8601String(),
    });

    await db.insert('produtos', {
      'nome': 'Produto B',
      'quantidade': 5,
      'preco': 45.00,
      'data_cadastro': DateTime.now().toIso8601String(),
    });

    await db.insert('produtos', {
      'nome': 'Produto C',
      'quantidade': 0,
      'preco': 15.75,
      'data_cadastro': DateTime.now().toIso8601String(),
    });
  }

  Future<List<Map<String, dynamic>>> getProdutos() async {
    final db = await database;
    return await db.query('produtos', orderBy: 'nome ASC');
  }

  Future<void> addProduto(String nome, int quantidade, double preco) async {
    final db = await database;
    await db.insert('produtos', {
      'nome': nome,
      'quantidade': quantidade,
      'preco': preco,
      'data_cadastro': DateTime.now().toIso8601String(),
    });
  }

  Future<void> updateQuantidade(int id, int novaQuantidade) async {
    final db = await database;
    await db.update(
      'produtos',
      {'quantidade': novaQuantidade},
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<void> deleteProduto(int id) async {
    final db = await database;
    await db.delete('produtos', where: 'id = ?', whereArgs: [id]);
  }

  Future<Map<String, dynamic>> getEstatisticas() async {
    final db = await database;
    final produtos = await getProdutos();
    
    final totalProdutos = produtos.length;
    final totalQuantidade = produtos.fold(0, (sum, p) => sum + (p['quantidade'] as int));
    final valorTotal = produtos.fold(0.0, (sum, p) => sum + ((p['quantidade'] as int) * (p['preco'] as double)));
    final estoqueBaixo = produtos.where((p) => (p['quantidade'] as int) <= 3).length;
    final semEstoque = produtos.where((p) => (p['quantidade'] as int) == 0).length;

    return {
      'totalProdutos': totalProdutos,
      'totalQuantidade': totalQuantidade,
      'valorTotal': valorTotal,
      'estoqueBaixo': estoqueBaixo,
      'semEstoque': semEstoque,
    };
  }

  Future close() async {
    final db = await database;
    db.close();
  }
}
