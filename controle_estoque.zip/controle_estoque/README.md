# 📦 Controle de Estoque - App Android

Aplicativo completo de controle de estoque desenvolvido em Flutter para Android.

## ✨ Funcionalidades

### 📊 Dashboard Principal
- Estatísticas em tempo real (total de produtos, itens, valor total)
- Alertas de estoque baixo e sem estoque
- Busca rápida por nome, código ou categoria
- Filtro por categorias
- Lista de produtos com informações detalhadas

### 📝 Cadastro de Produtos
- Nome, código, categoria, preço
- Quantidade em estoque
- Estoque mínimo para alertas
- Descrição opcional
- Autocompletar para categorias existentes

### 📦 Controle de Estoque
- Entrada de produtos (adicionar quantidade)
- Saída de produtos (remover quantidade)
- Alertas visuais para estoque baixo/zerado
- Histórico de cadastro e atualização

### 🔍 Detalhes do Produto
- Visualização completa de informações
- Cálculo automático de valor total em estoque
- Edição rápida
- Movimentação de estoque (entrada/saída)

### 💾 Armazenamento
- Banco de dados SQLite local
- Funciona 100% offline
- Dados persistentes no dispositivo

## 🚀 Como Instalar e Executar

### Pré-requisitos
- Flutter SDK 3.0 ou superior
- Android Studio ou VS Code
- Dispositivo Android ou emulador

### Passo a Passo

1. **Instalar o Flutter**
   - Baixe em: https://flutter.dev/docs/get-started/install
   - Siga as instruções para seu sistema operacional

2. **Verificar instalação**
   ```bash
   flutter doctor
   ```

3. **Navegar até a pasta do projeto**
   ```bash
   cd controle_estoque
   ```

4. **Instalar dependências**
   ```bash
   flutter pub get
   ```

5. **Conectar dispositivo Android ou iniciar emulador**
   - Verifique dispositivos disponíveis:
   ```bash
   flutter devices
   ```

6. **Executar o aplicativo**
   ```bash
   flutter run
   ```

### Gerar APK para Instalação

Para criar um arquivo APK instalável:

```bash
flutter build apk --release
```

O APK será gerado em: `build/app/outputs/flutter-apk/app-release.apk`

Copie esse arquivo para seu dispositivo Android e instale.

## 📱 Capturas de Tela

### Tela Principal
- Dashboard com estatísticas
- Lista de produtos com filtros
- Indicadores visuais de estoque

### Cadastro de Produtos
- Formulário completo e intuitivo
- Validação de campos
- Sugestões de categorias

### Detalhes e Movimentação
- Informações completas do produto
- Botões de entrada/saída de estoque
- Histórico de alterações

## 🎨 Tecnologias Utilizadas

- **Flutter 3.x** - Framework de desenvolvimento
- **Dart** - Linguagem de programação
- **SQLite** - Banco de dados local
- **Material Design 3** - Design moderno e responsivo

## 📦 Dependências Principais

```yaml
dependencies:
  flutter:
    sdk: flutter
  sqflite: ^2.3.0          # Banco de dados SQLite
  path_provider: ^2.1.1    # Acesso a diretórios do sistema
  intl: ^0.18.1            # Formatação de datas e valores
```

## 🔧 Estrutura do Projeto

```
lib/
├── main.dart                    # Entrada do aplicativo
├── models/
│   └── produto.dart            # Modelo de dados
├── database/
│   └── database_helper.dart    # Gerenciamento do banco
└── screens/
    ├── home_screen.dart        # Tela principal
    ├── produto_form_screen.dart    # Cadastro/edição
    └── produto_detail_screen.dart  # Detalhes do produto
```

## 💡 Funcionalidades Futuras (Sugestões)

- 📊 Relatórios e gráficos de movimentação
- 📸 Scan de código de barras
- 📤 Exportar dados (CSV, PDF)
- ☁️ Sincronização em nuvem
- 👥 Multi-usuário com permissões
- 🔔 Notificações de estoque baixo
- 📈 Análise de vendas e tendências

## 🤝 Suporte

Para dúvidas ou problemas:
1. Verifique se todas as dependências estão instaladas
2. Execute `flutter clean` e `flutter pub get`
3. Certifique-se de ter a versão correta do Flutter

## 📄 Licença

Projeto desenvolvido para fins educacionais e comerciais.

---

**Desenvolvido com ❤️ usando Flutter**
