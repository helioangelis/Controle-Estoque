package com.example.controle_estoque

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
