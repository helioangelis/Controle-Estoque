class Produto {
  int? id;
  String nome;
  String codigo;
  String categoria;
  double preco;
  int quantidade;
  int estoqueMinimo;
  String? descricao;
  DateTime dataCadastro;
  DateTime? dataAtualizacao;

  Produto({
    this.id,
    required this.nome,
    required this.codigo,
    required this.categoria,
    required this.preco,
    required this.quantidade,
    this.estoqueMinimo = 10,
    this.descricao,
    DateTime? dataCadastro,
    this.dataAtualizacao,
  }) : dataCadastro = dataCadastro ?? DateTime.now();

  // Verificar se está com estoque baixo
  bool get estoqueBaixo => quantidade <= estoqueMinimo;

  // Verificar se está sem estoque
  bool get semEstoque => quantidade == 0;

  // Valor total em estoque
  double get valorTotal => preco * quantidade;

  // Converter para Map (para salvar no banco)
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'nome': nome,
      'codigo': codigo,
      'categoria': categoria,
      'preco': preco,
      'quantidade': quantidade,
      'estoqueMinimo': estoqueMinimo,
      'descricao': descricao,
      'dataCadastro': dataCadastro.toIso8601String(),
      'dataAtualizacao': dataAtualizacao?.toIso8601String(),
    };
  }

  // Criar a partir de Map (carregar do banco)
  factory Produto.fromMap(Map<String, dynamic> map) {
    return Produto(
      id: map['id'],
      nome: map['nome'],
      codigo: map['codigo'],
      categoria: map['categoria'],
      preco: map['preco'],
      quantidade: map['quantidade'],
      estoqueMinimo: map['estoqueMinimo'] ?? 10,
      descricao: map['descricao'],
      dataCadastro: DateTime.parse(map['dataCadastro']),
      dataAtualizacao: map['dataAtualizacao'] != null
          ? DateTime.parse(map['dataAtualizacao'])
          : null,
    );
  }

  // Copiar com alterações
  Produto copyWith({
    int? id,
    String? nome,
    String? codigo,
    String? categoria,
    double? preco,
    int? quantidade,
    int? estoqueMinimo,
    String? descricao,
    DateTime? dataCadastro,
    DateTime? dataAtualizacao,
  }) {
    return Produto(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      codigo: codigo ?? this.codigo,
      categoria: categoria ?? this.categoria,
      preco: preco ?? this.preco,
      quantidade: quantidade ?? this.quantidade,
      estoqueMinimo: estoqueMinimo ?? this.estoqueMinimo,
      descricao: descricao ?? this.descricao,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      dataAtualizacao: dataAtualizacao ?? this.dataAtualizacao,
    );
  }
}
