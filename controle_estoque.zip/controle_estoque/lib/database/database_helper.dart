import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/produto.dart';

class DatabaseHelper {
  static final DatabaseHelper instance = DatabaseHelper._init();
  static Database? _database;

  DatabaseHelper._init();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('estoque.db');
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, filePath);

    return await openDatabase(
      path,
      version: 1,
      onCreate: _createDB,
    );
  }

  Future<void> _createDB(Database db, int version) async {
    await db.execute('''
      CREATE TABLE produtos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT NOT NULL,
        codigo TEXT NOT NULL UNIQUE,
        categoria TEXT NOT NULL,
        preco REAL NOT NULL,
        quantidade INTEGER NOT NULL,
        estoqueMinimo INTEGER NOT NULL DEFAULT 10,
        descricao TEXT,
        dataCadastro TEXT NOT NULL,
        dataAtualizacao TEXT
      )
    ''');

    // Inserir alguns produtos de exemplo
    await db.insert('produtos', {
      'nome': 'Notebook Dell',
      'codigo': 'NB001',
      'categoria': 'Eletrônicos',
      'preco': 3500.00,
      'quantidade': 5,
      'estoqueMinimo': 2,
      'descricao': 'Notebook Dell Inspiron 15',
      'dataCadastro': DateTime.now().toIso8601String(),
    });

    await db.insert('produtos', {
      'nome': 'Mouse Logitech',
      'codigo': 'MS001',
      'categoria': 'Acessórios',
      'preco': 85.00,
      'quantidade': 25,
      'estoqueMinimo': 10,
      'descricao': 'Mouse sem fio Logitech M170',
      'dataCadastro': DateTime.now().toIso8601String(),
    });

    await db.insert('produtos', {
      'nome': 'Teclado Mecânico',
      'codigo': 'KB001',
      'categoria': 'Acessórios',
      'preco': 350.00,
      'quantidade': 8,
      'estoqueMinimo': 5,
      'descricao': 'Teclado mecânico RGB',
      'dataCadastro': DateTime.now().toIso8601String(),
    });
  }

  // Criar produto
  Future<Produto> createProduto(Produto produto) async {
    final db = await database;
    final id = await db.insert('produtos', produto.toMap());
    return produto.copyWith(id: id);
  }

  // Ler todos os produtos
  Future<List<Produto>> getProdutos() async {
    final db = await database;
    final result = await db.query('produtos', orderBy: 'nome ASC');
    return result.map((map) => Produto.fromMap(map)).toList();
  }

  // Ler produto por ID
  Future<Produto?> getProduto(int id) async {
    final db = await database;
    final maps = await db.query(
      'produtos',
      where: 'id = ?',
      whereArgs: [id],
    );

    if (maps.isNotEmpty) {
      return Produto.fromMap(maps.first);
    }
    return null;
  }

  // Buscar produtos
  Future<List<Produto>> searchProdutos(String query) async {
    final db = await database;
    final result = await db.query(
      'produtos',
      where: 'nome LIKE ? OR codigo LIKE ? OR categoria LIKE ?',
      whereArgs: ['%$query%', '%$query%', '%$query%'],
      orderBy: 'nome ASC',
    );
    return result.map((map) => Produto.fromMap(map)).toList();
  }

  // Filtrar por categoria
  Future<List<Produto>> getProdutosPorCategoria(String categoria) async {
    final db = await database;
    final result = await db.query(
      'produtos',
      where: 'categoria = ?',
      whereArgs: [categoria],
      orderBy: 'nome ASC',
    );
    return result.map((map) => Produto.fromMap(map)).toList();
  }

  // Produtos com estoque baixo
  Future<List<Produto>> getProdutosEstoqueBaixo() async {
    final db = await database;
    final result = await db.rawQuery(
      'SELECT * FROM produtos WHERE quantidade <= estoqueMinimo ORDER BY quantidade ASC',
    );
    return result.map((map) => Produto.fromMap(map)).toList();
  }

  // Atualizar produto
  Future<int> updateProduto(Produto produto) async {
    final db = await database;
    produto = produto.copyWith(dataAtualizacao: DateTime.now());
    return db.update(
      'produtos',
      produto.toMap(),
      where: 'id = ?',
      whereArgs: [produto.id],
    );
  }

  // Atualizar quantidade (entrada/saída)
  Future<int> atualizarQuantidade(int id, int novaQuantidade) async {
    final db = await database;
    return db.update(
      'produtos',
      {
        'quantidade': novaQuantidade,
        'dataAtualizacao': DateTime.now().toIso8601String(),
      },
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  // Deletar produto
  Future<int> deleteProduto(int id) async {
    final db = await database;
    return db.delete(
      'produtos',
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  // Obter categorias únicas
  Future<List<String>> getCategorias() async {
    final db = await database;
    final result = await db.rawQuery(
      'SELECT DISTINCT categoria FROM produtos ORDER BY categoria ASC',
    );
    return result.map((row) => row['categoria'] as String).toList();
  }

  // Estatísticas
  Future<Map<String, dynamic>> getEstatisticas() async {
    final db = await database;
    final produtos = await getProdutos();
    
    final totalProdutos = produtos.length;
    final totalItens = produtos.fold(0, (sum, p) => sum + p.quantidade);
    final valorTotal = produtos.fold(0.0, (sum, p) => sum + p.valorTotal);
    final estoqueBaixo = produtos.where((p) => p.estoqueBaixo).length;
    final semEstoque = produtos.where((p) => p.semEstoque).length;

    return {
      'totalProdutos': totalProdutos,
      'totalItens': totalItens,
      'valorTotal': valorTotal,
      'estoqueBaixo': estoqueBaixo,
      'semEstoque': semEstoque,
    };
  }

  // Fechar banco
  Future close() async {
    final db = await database;
    db.close();
  }
}
