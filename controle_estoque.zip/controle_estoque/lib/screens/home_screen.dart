import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../database/database_helper.dart';
import '../models/produto.dart';
import 'produto_form_screen.dart';
import 'produto_detail_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final DatabaseHelper _dbHelper = DatabaseHelper.instance;
  List<Produto> _produtos = [];
  List<Produto> _produtosFiltrados = [];
  String _filtroCategoria = 'Todos';
  bool _isLoading = true;
  final TextEditingController _searchController = TextEditingController();
  Map<String, dynamic> _estatisticas = {};

  @override
  void initState() {
    super.initState();
    _carregarDados();
  }

  Future<void> _carregarDados() async {
    setState(() => _isLoading = true);
    final produtos = await _dbHelper.getProdutos();
    final stats = await _dbHelper.getEstatisticas();
    setState(() {
      _produtos = produtos;
      _produtosFiltrados = produtos;
      _estatisticas = stats;
      _isLoading = false;
    });
  }

  void _filtrarProdutos(String query) {
    setState(() {
      if (query.isEmpty) {
        _produtosFiltrados = _filtroCategoria == 'Todos'
            ? _produtos
            : _produtos.where((p) => p.categoria == _filtroCategoria).toList();
      } else {
        _produtosFiltrados = _produtos.where((produto) {
          final matchQuery = produto.nome.toLowerCase().contains(query.toLowerCase()) ||
              produto.codigo.toLowerCase().contains(query.toLowerCase());
          final matchCategoria = _filtroCategoria == 'Todos' || produto.categoria == _filtroCategoria;
          return matchQuery && matchCategoria;
        }).toList();
      }
    });
  }

  void _filtrarPorCategoria(String categoria) {
    setState(() {
      _filtroCategoria = categoria;
      _filtrarProdutos(_searchController.text);
    });
  }

  Future<void> _navegarParaForm([Produto? produto]) async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ProdutoFormScreen(produto: produto),
      ),
    );
    if (result == true) {
      _carregarDados();
    }
  }

  Future<void> _navegarParaDetalhes(Produto produto) async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ProdutoDetailScreen(produto: produto),
      ),
    );
    if (result == true) {
      _carregarDados();
    }
  }

  Future<void> _deletarProduto(Produto produto) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Confirmar exclusão'),
        content: Text('Deseja realmente excluir "${produto.nome}"?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancelar'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('Excluir'),
          ),
        ],
      ),
    );

    if (confirm == true && produto.id != null) {
      await _dbHelper.deleteProduto(produto.id!);
      _carregarDados();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Produto excluído com sucesso')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final currencyFormat = NumberFormat.currency(locale: 'pt_BR', symbol: 'R\$');

    return Scaffold(
      appBar: AppBar(
        title: const Text('Controle de Estoque'),
        actions: [
          PopupMenuButton<String>(
            icon: const Icon(Icons.filter_list),
            onSelected: _filtrarPorCategoria,
            itemBuilder: (context) {
              final categorias = ['Todos', ..._produtos.map((p) => p.categoria).toSet().toList()];
              return categorias.map((categoria) {
                return PopupMenuItem(
                  value: categoria,
                  child: Row(
                    children: [
                      if (categoria == _filtroCategoria)
                        const Icon(Icons.check, size: 20),
                      if (categoria == _filtroCategoria)
                        const SizedBox(width: 8),
                      Text(categoria),
                    ],
                  ),
                );
              }).toList();
            },
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                // Estatísticas
                Container(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: _buildStatCard(
                              'Produtos',
                              '${_estatisticas['totalProdutos'] ?? 0}',
                              Icons.inventory_2,
                              Colors.blue,
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: _buildStatCard(
                              'Total Itens',
                              '${_estatisticas['totalItens'] ?? 0}',
                              Icons.shopping_basket,
                              Colors.green,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          Expanded(
                            child: _buildStatCard(
                              'Valor Total',
                              currencyFormat.format(_estatisticas['valorTotal'] ?? 0),
                              Icons.attach_money,
                              Colors.purple,
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: _buildStatCard(
                              'Estoque Baixo',
                              '${_estatisticas['estoqueBaixo'] ?? 0}',
                              Icons.warning,
                              Colors.orange,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),

                // Barra de pesquisa
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: TextField(
                    controller: _searchController,
                    decoration: InputDecoration(
                      hintText: 'Buscar produto...',
                      prefixIcon: const Icon(Icons.search),
                      suffixIcon: _searchController.text.isNotEmpty
                          ? IconButton(
                              icon: const Icon(Icons.clear),
                              onPressed: () {
                                _searchController.clear();
                                _filtrarProdutos('');
                              },
                            )
                          : null,
                    ),
                    onChanged: _filtrarProdutos,
                  ),
                ),

                const SizedBox(height: 16),

                // Lista de produtos
                Expanded(
                  child: _produtosFiltrados.isEmpty
                      ? Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.inventory_2_outlined,
                                  size: 64, color: Colors.grey[400]),
                              const SizedBox(height: 16),
                              Text(
                                'Nenhum produto encontrado',
                                style: TextStyle(
                                  fontSize: 18,
                                  color: Colors.grey[600],
                                ),
                              ),
                            ],
                          ),
                        )
                      : ListView.builder(
                          padding: const EdgeInsets.symmetric(horizontal: 16),
                          itemCount: _produtosFiltrados.length,
                          itemBuilder: (context, index) {
                            final produto = _produtosFiltrados[index];
                            return _buildProdutoCard(produto, currencyFormat);
                          },
                        ),
                ),
              ],
            ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _navegarParaForm(),
        icon: const Icon(Icons.add),
        label: const Text('Novo Produto'),
      ),
    );
  }

  Widget _buildStatCard(String label, String value, IconData icon, Color color) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            Icon(icon, color: color, size: 28),
            const SizedBox(height: 8),
            Text(
              value,
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              label,
              style: TextStyle(
                fontSize: 12,
                color: Colors.grey[600],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildProdutoCard(Produto produto, NumberFormat currencyFormat) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: InkWell(
        onTap: () => _navegarParaDetalhes(produto),
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          produto.nome,
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'Código: ${produto.codigo}',
                          style: TextStyle(
                            fontSize: 13,
                            color: Colors.grey[600],
                          ),
                        ),
                      ],
                    ),
                  ),
                  PopupMenuButton(
                    itemBuilder: (context) => [
                      const PopupMenuItem(
                        value: 'edit',
                        child: Row(
                          children: [
                            Icon(Icons.edit, size: 20),
                            SizedBox(width: 8),
                            Text('Editar'),
                          ],
                        ),
                      ),
                      const PopupMenuItem(
                        value: 'delete',
                        child: Row(
                          children: [
                            Icon(Icons.delete, size: 20, color: Colors.red),
                            SizedBox(width: 8),
                            Text('Excluir', style: TextStyle(color: Colors.red)),
                          ],
                        ),
                      ),
                    ],
                    onSelected: (value) {
                      if (value == 'edit') {
                        _navegarParaForm(produto);
                      } else if (value == 'delete') {
                        _deletarProduto(produto);
                      }
                    },
                  ),
                ],
              ),
              const Divider(height: 16),
              Row(
                children: [
                  Expanded(
                    child: _buildInfoChip(
                      Icons.category,
                      produto.categoria,
                      Colors.blue,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: _buildInfoChip(
                      Icons.attach_money,
                      currencyFormat.format(produto.preco),
                      Colors.green,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(
                    child: _buildInfoChip(
                      Icons.inventory,
                      '${produto.quantidade} un.',
                      produto.semEstoque
                          ? Colors.red
                          : produto.estoqueBaixo
                              ? Colors.orange
                              : Colors.blue,
                    ),
                  ),
                  if (produto.estoqueBaixo) ...[
                    const SizedBox(width: 8),
                    Chip(
                      label: Text(
                        produto.semEstoque ? 'SEM ESTOQUE' : 'ESTOQUE BAIXO',
                        style: const TextStyle(fontSize: 11, color: Colors.white),
                      ),
                      backgroundColor: produto.semEstoque ? Colors.red : Colors.orange,
                      padding: EdgeInsets.zero,
                      visualDensity: VisualDensity.compact,
                    ),
                  ],
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildInfoChip(IconData icon, String label, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 16, color: color),
          const SizedBox(width: 4),
          Flexible(
            child: Text(
              label,
              style: TextStyle(
                fontSize: 12,
                color: color,
                fontWeight: FontWeight.w500,
              ),
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }
}
