import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import '../database/database_helper.dart';
import '../models/produto.dart';
import 'produto_form_screen.dart';

class ProdutoDetailScreen extends StatefulWidget {
  final Produto produto;

  const ProdutoDetailScreen({super.key, required this.produto});

  @override
  State<ProdutoDetailScreen> createState() => _ProdutoDetailScreenState();
}

class _ProdutoDetailScreenState extends State<ProdutoDetailScreen> {
  final DatabaseHelper _dbHelper = DatabaseHelper.instance;
  late Produto _produto;
  final TextEditingController _quantidadeController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _produto = widget.produto;
  }

  Future<void> _atualizarQuantidade(bool isEntrada) async {
    final quantidade = int.tryParse(_quantidadeController.text);
    if (quantidade == null || quantidade <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Informe uma quantidade válida'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    final novaQuantidade = isEntrada
        ? _produto.quantidade + quantidade
        : _produto.quantidade - quantidade;

    if (novaQuantidade < 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Quantidade em estoque insuficiente'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    await _dbHelper.atualizarQuantidade(_produto.id!, novaQuantidade);
    final produtoAtualizado = await _dbHelper.getProduto(_produto.id!);

    setState(() {
      _produto = produtoAtualizado!;
      _quantidadeController.clear();
    });

    if (mounted) {
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            isEntrada ? 'Entrada registrada com sucesso' : 'Saída registrada com sucesso',
          ),
        ),
      );
    }
  }

  void _mostrarDialogMovimentacao(bool isEntrada) {
    _quantidadeController.clear();
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(isEntrada ? 'Entrada de Estoque' : 'Saída de Estoque'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              _produto.nome,
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Text('Estoque atual: ${_produto.quantidade} unidades'),
            const SizedBox(height: 16),
            TextField(
              controller: _quantidadeController,
              decoration: InputDecoration(
                labelText: 'Quantidade',
                prefixIcon: Icon(isEntrada ? Icons.add : Icons.remove),
                border: const OutlineInputBorder(),
              ),
              keyboardType: TextInputType.number,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
              autofocus: true,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () => _atualizarQuantidade(isEntrada),
            child: const Text('Confirmar'),
          ),
        ],
      ),
    );
  }

  Future<void> _editarProduto() async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ProdutoFormScreen(produto: _produto),
      ),
    );

    if (result == true) {
      final produtoAtualizado = await _dbHelper.getProduto(_produto.id!);
      if (produtoAtualizado != null) {
        setState(() {
          _produto = produtoAtualizado;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final currencyFormat = NumberFormat.currency(locale: 'pt_BR', symbol: 'R\$');
    final dateFormat = DateFormat('dd/MM/yyyy HH:mm');

    return Scaffold(
      appBar: AppBar(
        title: const Text('Detalhes do Produto'),
        actions: [
          IconButton(
            icon: const Icon(Icons.edit),
            onPressed: _editarProduto,
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Header com status
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: _produto.semEstoque
                      ? [Colors.red, Colors.red.shade700]
                      : _produto.estoqueBaixo
                          ? [Colors.orange, Colors.orange.shade700]
                          : [Colors.blue, Colors.blue.shade700],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
              child: Column(
                children: [
                  Icon(
                    _produto.semEstoque
                        ? Icons.error_outline
                        : _produto.estoqueBaixo
                            ? Icons.warning_amber
                            : Icons.inventory_2,
                    size: 64,
                    color: Colors.white,
                  ),
                  const SizedBox(height: 16),
                  Text(
                    _produto.nome,
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Código: ${_produto.codigo}',
                    style: const TextStyle(
                      fontSize: 16,
                      color: Colors.white70,
                    ),
                  ),
                  if (_produto.semEstoque || _produto.estoqueBaixo) ...[
                    const SizedBox(height: 12),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text(
                        _produto.semEstoque ? 'SEM ESTOQUE' : 'ESTOQUE BAIXO',
                        style: TextStyle(
                          color: _produto.semEstoque ? Colors.red : Colors.orange,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ],
              ),
            ),

            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // Informações principais
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Informações',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const Divider(),
                          _buildInfoRow(Icons.category, 'Categoria', _produto.categoria),
                          _buildInfoRow(
                            Icons.attach_money,
                            'Preço unitário',
                            currencyFormat.format(_produto.preco),
                          ),
                          _buildInfoRow(
                            Icons.inventory,
                            'Quantidade em estoque',
                            '${_produto.quantidade} unidades',
                          ),
                          _buildInfoRow(
                            Icons.warning,
                            'Estoque mínimo',
                            '${_produto.estoqueMinimo} unidades',
                          ),
                          _buildInfoRow(
                            Icons.calculate,
                            'Valor total em estoque',
                            currencyFormat.format(_produto.valorTotal),
                          ),
                        ],
                      ),
                    ),
                  ),

                  // Descrição
                  if (_produto.descricao != null && _produto.descricao!.isNotEmpty)
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Descrição',
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const Divider(),
                            Text(_produto.descricao!),
                          ],
                        ),
                      ),
                    ),

                  // Datas
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Histórico',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const Divider(),
                          _buildInfoRow(
                            Icons.calendar_today,
                            'Cadastrado em',
                            dateFormat.format(_produto.dataCadastro),
                          ),
                          if (_produto.dataAtualizacao != null)
                            _buildInfoRow(
                              Icons.update,
                              'Última atualização',
                              dateFormat.format(_produto.dataAtualizacao!),
                            ),
                        ],
                      ),
                    ),
                  ),

                  const SizedBox(height: 16),

                  // Botões de ação
                  Row(
                    children: [
                      Expanded(
                        child: FilledButton.icon(
                          onPressed: () => _mostrarDialogMovimentacao(true),
                          icon: const Icon(Icons.add),
                          label: const Text('Entrada'),
                          style: FilledButton.styleFrom(
                            backgroundColor: Colors.green,
                            padding: const EdgeInsets.all(16),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: FilledButton.icon(
                          onPressed: () => _mostrarDialogMovimentacao(false),
                          icon: const Icon(Icons.remove),
                          label: const Text('Saída'),
                          style: FilledButton.styleFrom(
                            backgroundColor: Colors.red,
                            padding: const EdgeInsets.all(16),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoRow(IconData icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Icon(icon, size: 20, color: Colors.grey[600]),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.grey[600],
                  ),
                ),
                Text(
                  value,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _quantidadeController.dispose();
    super.dispose();
  }
}
