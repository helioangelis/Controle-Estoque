import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../database/database_helper.dart';
import '../models/produto.dart';

class ProdutoFormScreen extends StatefulWidget {
  final Produto? produto;

  const ProdutoFormScreen({super.key, this.produto});

  @override
  State<ProdutoFormScreen> createState() => _ProdutoFormScreenState();
}

class _ProdutoFormScreenState extends State<ProdutoFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final DatabaseHelper _dbHelper = DatabaseHelper.instance;

  late TextEditingController _nomeController;
  late TextEditingController _codigoController;
  late TextEditingController _categoriaController;
  late TextEditingController _precoController;
  late TextEditingController _quantidadeController;
  late TextEditingController _estoqueMinimoController;
  late TextEditingController _descricaoController;

  bool _isLoading = false;
  List<String> _categoriasSugestoes = [];

  @override
  void initState() {
    super.initState();
    _nomeController = TextEditingController(text: widget.produto?.nome ?? '');
    _codigoController = TextEditingController(text: widget.produto?.codigo ?? '');
    _categoriaController = TextEditingController(text: widget.produto?.categoria ?? '');
    _precoController = TextEditingController(
      text: widget.produto?.preco.toStringAsFixed(2) ?? '',
    );
    _quantidadeController = TextEditingController(
      text: widget.produto?.quantidade.toString() ?? '',
    );
    _estoqueMinimoController = TextEditingController(
      text: widget.produto?.estoqueMinimo.toString() ?? '10',
    );
    _descricaoController = TextEditingController(text: widget.produto?.descricao ?? '');

    _carregarCategorias();
  }

  Future<void> _carregarCategorias() async {
    final categorias = await _dbHelper.getCategorias();
    setState(() {
      _categoriasSugestoes = categorias;
    });
  }

  Future<void> _salvar() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isLoading = true);

    try {
      final produto = Produto(
        id: widget.produto?.id,
        nome: _nomeController.text.trim(),
        codigo: _codigoController.text.trim(),
        categoria: _categoriaController.text.trim(),
        preco: double.parse(_precoController.text.replaceAll(',', '.')),
        quantidade: int.parse(_quantidadeController.text),
        estoqueMinimo: int.parse(_estoqueMinimoController.text),
        descricao: _descricaoController.text.trim().isNotEmpty
            ? _descricaoController.text.trim()
            : null,
        dataCadastro: widget.produto?.dataCadastro,
      );

      if (widget.produto == null) {
        await _dbHelper.createProduto(produto);
      } else {
        await _dbHelper.updateProduto(produto);
      }

      if (mounted) {
        Navigator.pop(context, true);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              widget.produto == null
                  ? 'Produto cadastrado com sucesso'
                  : 'Produto atualizado com sucesso',
            ),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Erro ao salvar produto: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } finally {
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.produto == null ? 'Novo Produto' : 'Editar Produto'),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    TextFormField(
                      controller: _nomeController,
                      decoration: const InputDecoration(
                        labelText: 'Nome do Produto',
                        prefixIcon: Icon(Icons.shopping_bag),
                      ),
                      textCapitalization: TextCapitalization.words,
                      validator: (value) {
                        if (value == null || value.trim().isEmpty) {
                          return 'Informe o nome do produto';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 16),
                    TextFormField(
                      controller: _codigoController,
                      decoration: const InputDecoration(
                        labelText: 'Código',
                        prefixIcon: Icon(Icons.qr_code),
                      ),
                      textCapitalization: TextCapitalization.characters,
                      validator: (value) {
                        if (value == null || value.trim().isEmpty) {
                          return 'Informe o código do produto';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 16),
                    Autocomplete<String>(
                      optionsBuilder: (TextEditingValue textEditingValue) {
                        if (textEditingValue.text.isEmpty) {
                          return const Iterable<String>.empty();
                        }
                        return _categoriasSugestoes.where((categoria) {
                          return categoria
                              .toLowerCase()
                              .contains(textEditingValue.text.toLowerCase());
                        });
                      },
                      onSelected: (String selection) {
                        _categoriaController.text = selection;
                      },
                      fieldViewBuilder: (context, controller, focusNode, onEditingComplete) {
                        controller.text = _categoriaController.text;
                        controller.addListener(() {
                          _categoriaController.text = controller.text;
                        });
                        return TextFormField(
                          controller: controller,
                          focusNode: focusNode,
                          decoration: const InputDecoration(
                            labelText: 'Categoria',
                            prefixIcon: Icon(Icons.category),
                          ),
                          textCapitalization: TextCapitalization.words,
                          validator: (value) {
                            if (value == null || value.trim().isEmpty) {
                              return 'Informe a categoria';
                            }
                            return null;
                          },
                          onEditingComplete: onEditingComplete,
                        );
                      },
                    ),
                    const SizedBox(height: 16),
                    TextFormField(
                      controller: _precoController,
                      decoration: const InputDecoration(
                        labelText: 'Preço',
                        prefixIcon: Icon(Icons.attach_money),
                        prefixText: 'R\$ ',
                      ),
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      inputFormatters: [
                        FilteringTextInputFormatter.allow(RegExp(r'^\d+\.?\d{0,2}')),
                      ],
                      validator: (value) {
                        if (value == null || value.trim().isEmpty) {
                          return 'Informe o preço';
                        }
                        final preco = double.tryParse(value.replaceAll(',', '.'));
                        if (preco == null || preco <= 0) {
                          return 'Preço inválido';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        Expanded(
                          child: TextFormField(
                            controller: _quantidadeController,
                            decoration: const InputDecoration(
                              labelText: 'Quantidade',
                              prefixIcon: Icon(Icons.inventory),
                            ),
                            keyboardType: TextInputType.number,
                            inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                            validator: (value) {
                              if (value == null || value.trim().isEmpty) {
                                return 'Informe a quantidade';
                              }
                              final quantidade = int.tryParse(value);
                              if (quantidade == null || quantidade < 0) {
                                return 'Quantidade inválida';
                              }
                              return null;
                            },
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: TextFormField(
                            controller: _estoqueMinimoController,
                            decoration: const InputDecoration(
                              labelText: 'Estoque Mínimo',
                              prefixIcon: Icon(Icons.warning),
                            ),
                            keyboardType: TextInputType.number,
                            inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                            validator: (value) {
                              if (value == null || value.trim().isEmpty) {
                                return 'Informe o estoque mínimo';
                              }
                              final estoqueMin = int.tryParse(value);
                              if (estoqueMin == null || estoqueMin < 0) {
                                return 'Valor inválido';
                              }
                              return null;
                            },
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    TextFormField(
                      controller: _descricaoController,
                      decoration: const InputDecoration(
                        labelText: 'Descrição (opcional)',
                        prefixIcon: Icon(Icons.description),
                        alignLabelWithHint: true,
                      ),
                      maxLines: 3,
                      textCapitalization: TextCapitalization.sentences,
                    ),
                    const SizedBox(height: 24),
                    FilledButton.icon(
                      onPressed: _salvar,
                      icon: const Icon(Icons.save),
                      label: Text(widget.produto == null ? 'Cadastrar' : 'Atualizar'),
                      style: FilledButton.styleFrom(
                        padding: const EdgeInsets.all(16),
                      ),
                    ),
                  ],
                ),
              ),
            ),
    );
  }

  @override
  void dispose() {
    _nomeController.dispose();
    _codigoController.dispose();
    _categoriaController.dispose();
    _precoController.dispose();
    _quantidadeController.dispose();
    _estoqueMinimoController.dispose();
    _descricaoController.dispose();
    super.dispose();
  }
}
